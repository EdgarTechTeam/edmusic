# home/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('upload/', views.upload_song, name='upload_song'),
     path('song/<int:song_id>/', views.song_detail, name='song_detail'),
]
