from django.shortcuts import render, redirect ,get_object_or_404
from .forms import SongUploadForm  # Import your form
from .models import Song


def index(request):
    songs = Song.objects.all()
    context = {
        'songs': songs
    }
    return render(request, 'home/index.html', context)

def song_detail(request, song_id):
    song = get_object_or_404(Song, id=song_id)
    return render(request, 'home/song_detail.html', {'song': song})

def upload_song(request):
    if request.method == 'POST':
        form = SongUploadForm(request.POST, request.FILES)
        if form.is_valid():
            # Process form data (save to database, handle file upload, etc.)
            form.save()
            return redirect('index')  # Redirect to home or another page after successful upload
    else:
        form = SongUploadForm()
    
    return render(request, 'home/upload.html', {'form': form})

'''
def index(request):
    songs = Song.objects.all()
    context = {
        'songs': songs
    }
    return render(request, 'index.html', context)'''