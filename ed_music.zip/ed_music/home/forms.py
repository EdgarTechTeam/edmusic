from django import forms
from .models import Song

class SongUploadForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)  # Call the __init__ method of the parent class
        self.fields['audio_file'].widget.attrs.update({'accept': 'audio/*'})  # Update widget attributes

    class Meta:
        model = Song
        fields = ['song_name', 'artist_name', 'song_tag', 'description', 'image', 'audio_file']
